import java.io.*;
import java.util.*;

public class Main {
    public static void main(String[] args) {
        try {
            BufferedReader reader = new BufferedReader(new FileReader("AssemblyCode.asm"));
            BufferedWriter writer = new BufferedWriter(new FileWriter("nowhitespace.txt"));
            String line;
            while ((line = reader.readLine()) != null) {
                if (line.startsWith("//")) {
                    continue;
                } else {
                    String x = line.replaceAll("//.*", "").replaceAll("\\s+", "");
                    if (!x.isEmpty()) {
                        writer.write(x);
                        writer.newLine();
                    }
                }
            }
            reader.close();
            writer.close();
            //symboltableole table
           reader = new BufferedReader(new FileReader("nowhitespace.txt"));
            writer = new BufferedWriter(new FileWriter("symboltable.txt"));
             while ((line = reader.readLine()) != null) {
                   if (line.startsWith("@")) {
                       String x=line.substring(1);
                       writer.write(x);
                       writer.newLine();
                   }
                    else if(line.startsWith("(")){
                        String x=line.substring(1,line.indexOf(")"));
                        writer.write(x);
                        writer.newLine();
                    }
                   }
             
               reader.close();
            writer.close();
            //hashmap lo read avadaniki
              reader = new BufferedReader(new FileReader("nowhitespace.txt"));
                Map<String, Integer> myMap = new HashMap<>();
        int i = 16,l=0;
        while ((line = reader.readLine()) != null) {
          if (line.startsWith("(")) {
        String labelName = line.substring(1, line.indexOf(")"));
            if (!myMap.containsKey(labelName)) {
                myMap.put(labelName, l);
            
            }
          }
          else{
          l++;
          }
        }
          //labels   ki 
        reader = new BufferedReader(new FileReader("nowhitespace.txt"));
        writer = new BufferedWriter(new FileWriter("variables&Labels.txt"));
        while ((line = reader.readLine()) != null) {
          if (line.startsWith("(")) {
        String labelName = line.substring(1, line.indexOf(")"));
        
            int number = myMap.get(labelName);
            continue;
    } 
    else if (line.startsWith("@R")) {
        String y = line.substring(2);
       
        
        String x = "@" + y;
        writer.write(x);
        writer.newLine();
    } 
     else if((line.startsWith("@SCREEN"))||(line.startsWith("@KBD"))||(line.startsWith("@SP"))||(line.startsWith("@LCL"))||(line.startsWith("@ARG"))||(line.startsWith("@THIS"))||(line.startsWith("@THAT"))){
        writer.write(line);
        writer.newLine();
                     
                 }
 
    else if ( line.substring(1).matches("\\d+")) {
        writer.write(line);
        writer.newLine();
   
}

    else if (line.startsWith("@")) {
        String variableName = line.substring(1);
        if (!myMap.containsKey(variableName)) {
            myMap.put(variableName, i);
            i++;
        }
        int number = myMap.get(variableName);
        String x = "@" + number;
        writer.write(x);
        writer.newLine();
    } 
    else {
        writer.write(line);
        writer.newLine();
    }
    l++;
}
reader.close();
writer.close();




//a instruction ki
         reader = new BufferedReader(new FileReader("variables&Labels.txt"));
         writer = new BufferedWriter(new FileWriter("ainst.hack"));
         while ((line = reader.readLine()) != null) {
             
                          
             if((line.startsWith("@SCREEN"))||(line.startsWith("@KBD"))||(line.startsWith("@SP"))||(line.startsWith("@LCL"))||(line.startsWith("@ARG"))||(line.startsWith("@THIS"))||(line.startsWith("@THAT"))){
                  Map<String, Integer> preDef = new HashMap<>();
                  preDef.put("SCREEN", 16384);
                preDef.put("KBD", 24576);
                preDef.put("SP", 0);
                preDef.put("LCL", 1);
                preDef.put("ARG", 2);
                preDef.put("THIS", 3);
                preDef.put("THAT", 4);
                int x=preDef.get(line.substring(1));
                 String b = Integer.toBinaryString(x);//binary ki
                while (b.length() < 16) {
                  b = "0" + b;
                }
                writer.write(b);
                writer.newLine();
             }
             
            else if(line.startsWith("@")){
                 int x= Integer.parseInt(line.substring(1));
                 String b = Integer.toBinaryString(x);//binary ki
                while (b.length() < 16) {
                  b = "0" + b;
                }
                writer.write(b);
                writer.newLine();
             }
            else{
                
                
            Map<String, String> dest = new HashMap<>();
            dest.put("" , "000");
            dest.put("M", "001");
            dest.put("D","010");
            dest.put("MD","011");
            dest.put("A","100");
            dest.put("AM","101");
            dest.put("AD","110");
            dest.put("AMD","111");
           Map<String, String> comp = new HashMap<>();
           comp.put("0", "0101010");
        comp.put("1", "0111111");
        comp.put("-1", "0111010");
        comp.put("D", "0001100");
        comp.put("A", "0110000");
        comp.put("!D", "0001101");
        comp.put("!A", "0110001");
        comp.put("-D", "0001111");
        comp.put("-A", "0110011");
        comp.put("D+1", "0011111");
        comp.put("A+1", "0110111");
        comp.put("D-1", "0001110");
        comp.put("A-1", "0110010");
        comp.put("D+A", "0000010");
        comp.put("A+D", "0000010");
        comp.put("D-A", "0010011");
        comp.put("A-D", "0000111");
        comp.put("D&A", "0000000");
        comp.put("A|D", "0010101");
        comp.put("A&D", "0000000");
        comp.put("D|A", "0010101");
        comp.put("M", "1110000");
        comp.put("!M", "1110001");
        comp.put("-M", "1110011");
        comp.put("M+1", "1110111");
        comp.put("M-1", "1110010");
        comp.put("D+M", "1000010");
        comp.put("M+D", "1000010");
        comp.put("D-M", "1010011");
        comp.put("M-D", "1000111");
        comp.put("D&M", "1000000");
        comp.put("M&D", "1000000");
        comp.put("M|D", "1010101");
        comp.put("D|M", "1010101");
          
         Map<String, String> jump = new HashMap<>();
            jump.put("", "000");
            jump.put("JGT", "001");
             jump.put("JEQ", "010");
            jump.put("JGE", "011");
            jump.put("JLT", "100");
            jump.put("JNE", "101");
            jump.put("JLE", "110");
            jump.put("JMP", "111");
            
       
           if((line.contains("="))&&(line.contains(";")))
            {
       String x=line.substring(0,line.indexOf("="));
       String y=line.substring(line.indexOf("="),line.indexOf(";"));
       String z=line.substring(line.indexOf(";")); 
               String c="111"+comp.get(y)+dest.get(x)+jump.get(z);
      writer.write(c);
       writer.newLine();
        }
        else if(line.contains("=")){
        String x=line.substring(0,line.indexOf("="));
        String y=line.substring(line.indexOf("=")+1);
        String z="";
        String c="111"+comp.get(y)+dest.get(x)+jump.get(z);
      writer.write(c);
       writer.newLine();
        }
      else if (line.contains(";")) {
          String x="";
    String y = line.substring(0, line.indexOf(";"));
    String z = line.substring(line.indexOf(";") + 1); // Add 1 to skip the semicolon
    String c = "111" + comp.get(y) + dest.get(x) + jump.get(z);
    writer.write(c);
    writer.newLine();
}

        else{
           String x="000";
           String y=line;
           String z="000";
String c="111"+comp.get(y)+dest.get(x)+jump.get(z);
  writer.write(c);
       writer.newLine();

        }
        
     
        
            }
             }
            reader.close();
            writer.close();
        } catch (IOException e) {
            System.out.println("Error reading or writing file");
            e.printStackTrace();
        }
    }
}